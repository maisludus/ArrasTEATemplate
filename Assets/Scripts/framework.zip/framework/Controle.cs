﻿


namespace Ludus.SDK.Framework
{
    public static class Controle
    {
        public static Configuracao configuracao;
    }
}
